# fibonacci_2048
<b>!!! NOTE !!!</b>
<p>There are two folders <br/>1: '2048_fib_as_VS_project' is a project code which opens in visual studio directly<br/>2: '2048_fibonacci' is a normal project which has all the source codes<br/> 
 <br/>
Bored of playing 2048 game with common  2 + 2 's, 4 + 4 's, .. then here you go a 2048 game that combines the numbers according to fibonacci series i.e if two numbers are contiguous in fibo series.
In this you can also resume the last played game.
You can also look at your position in the leaderboard which is local to particular PC.
